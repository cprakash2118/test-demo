# KubeVirtStack development plan

## Product outcome

A HawkStack architect selects a VMware estate, inspects trustworthy VM inventory, understands migration blockers and saves a draft wave for OpenShift Virtualization. The first pilot ends with an explainable plan. Production cutover is a separate release decision.

## Platform decision

| Layer | Proposed choice | Reason for this project |
|---|---|---|
| Source and review | Private GitHub monorepo, pull requests, GitHub Actions | One history for the API contract and both implementations |
| Developer workstation | Linux or Windows with WSL2, Git and Codex | One laptop can host both worktrees. The lab can be remote. |
| Frontend today | Browser JavaScript, HTML, CSS | The supplied prototype runs immediately |
| Frontend for pilot | React, TypeScript and Vite with Node.js 24 for builds | Reuse the design, share typed data models and test filter and wave behavior |
| API | Python 3.12, FastAPI, Uvicorn | Typed requests, OpenAPI and familiar Python tooling |
| Discovery | pyVmomi in a server-side worker | Retrieve vCenter inventory using a read-only principal |
| Persistence | PostgreSQL with SQLAlchemy and Alembic migrations | Model providers, snapshots, findings and waves with transactional constraints |
| Runtime platform | Podman for local containers, then a dedicated OpenShift project | Matches the target environment and enables on-premises lab deployment |
| Authentication for pilot | Existing identity provider through OIDC; viewer and planner roles | Scope inventory access and wave editing to the correct workspace |

Ship the frontend as static assets with a same-origin /api route to the API service. Keep discovery separate from HTTP requests. The worker reaches the lab vCenter over TLS. The API and worker use PostgreSQL. Use the live private demo for product reviews while a development namespace exercises real integrations. The pilot can run without an LLM or GPU.

## Delivery sequence

Planning estimate: four to six weeks for a lab pilot, assuming two active engineering workstreams, one HawkStack reviewer, and timely access to vCenter and OpenShift. Estimates are elapsed working time, and the two streams overlap. Lab access and identity integration can move the dates.

| Stage | Frontend developer | Backend developer | Acceptance by Chandra |
|---|---|---|---|
| Baseline and contract, days 1–2 | Reproduce the shipped demo and record its key flows | Review inventory schema and stable identity rules | Demo runs from a fresh checkout; both agents agree on example payload and errors |
| Inventory slice, week 1 | Render list and detail against the contract fixture; support loading, empty, error and unassessed states | Implement list/detail and test filtering, ordering, pagination and 404 against fixtures | Switch the UI from fixture to API and compare the same workload in both views |
| Read-only discovery, week 2 | Display source, last successful refresh and stale state | Read VMs, disks and NICs; persist complete snapshots; expose authorized refresh status | Match at least three VMs to vCenter, including CPU, memory and disks; rerun discovery with zero duplicates |
| Readiness, week 3 | Show per-check evidence, status, reason and corrective action | Compare source inventory with target network/storage mappings and a versioned rule set | Demonstrate ready, review, blocked and unassessed cases using known lab fixtures |
| Wave planning, week 4 | Add shared draft creation, membership and a review screen | Persist waves; validate eligibility against the latest complete assessment; reject conflicting memberships transactionally | Two sessions see the same draft; concurrent attempts to claim the same VM produce one assignment and an actionable conflict |
| OpenShift pilot, weeks 5–6 if needed | Verify browser navigation, keyboard support and pilot report view | Package images, configure Route/TLS, Secrets, OIDC, role checks, logs, health probes and database restore | Deploy in the lab, verify role separation, restore a draft and repeat the inventory-to-wave demonstration |

## First integration contract

Use contracts/openapi.json as the draft interface and contracts/inventory.example.json as the list fixture. Memory is MiB, disk capacity is bytes, timestamps use UTC. The workload ID is opaque to clients. The backend enforces uniqueness on (provider ID, source managed object ID). Display names can change or repeat. The initial list and detail operations represent one completed snapshot. Extend the contract before adding refresh jobs, target mappings, findings or waves.

An incomplete refresh retains the last complete snapshot, marks the source stale and exposes the failure time. A missing permission or missing target mapping must be visible in the assessment. A successful inventory read alone cannot mark a VM ready. Require evidence for mandatory checks and document the rule version.

## Codex assignments

### Frontend developer — first pull request

> Work in the frontend worktree. Implement a typed inventory client and list/detail view using contracts/openapi.json and contracts/inventory.example.json. Preserve the original demo as an explicit demo mode while introducing the React/TypeScript frontend. Keep sample waves separate from connected inventory. Render unassessed, loading, empty, error and stale states. Demonstrate that a failed live fetch shows an error. Include run instructions and a browser test for search, status filtering and opening VM details. Open a PR with screenshots and the checks you ran.

### Backend developer — first pull request

> Work in the backend worktree. Build a FastAPI service with GET /api/v1/vms and GET /api/v1/vms/{id} against the supplied fixture. Implement case-insensitive name/OS search, status filtering, stable ordering, pagination and typed 404 errors. Document the development command and test the supplied examples, filtered counts, an empty page and an unknown ID. Keep the first PR runnable offline. Open a second PR for a read-only vCenter adapter, validated with lab access.

### Maintainer and review

Chandra owns the API contract and accepts milestones. Merge the contract first, then develop in separate worktrees. Review both PRs against the same fixture. For the integration check, serve the UI and route /api to the backend, select a VM by ID, and compare the detail screen with the API response. Add CI in the corresponding implementation PRs: TypeScript checks and UI tests for frontend, pytest and contract checks for backend, and one end-to-end smoke test after both merge. Use a fresh Codex review of the combined diff and a human review before merging to main.

## Pilot inputs and tests

- Supply the lab vCenter version, trusted CA, provider address, reachable worker location and a scoped read-only account through the lab secret store.
- Record target OpenShift Virtualization and MTV versions, target namespace, network mappings and storage classes. Compare three representative source VMs including one multi-disk or multi-NIC VM.
- Exercise duplicate display names, renamed VMs, a missing mapping, a partial inventory read, expired credentials and an unreachable provider. Verify that refresh failure preserves the last complete data.
- Compare VM assignments before and after refresh. If evidence has changed, require reassessment before finalizing the wave. Track the source snapshot and assessment version in the wave.
- Demonstrate a working fresh deployment and measure discovery time on the actual estate. Set a scale target from that baseline.

## After the pilot

1. Add a reviewable plan export with source IDs, target mappings and assessment evidence.
2. Evaluate Red Hat Migration Toolkit for Virtualization (MTV) for execution. Start by generating a draft plan against the lab's installed API schema. Add explicit approval, execution status, interruption recovery and audit history before implementing cutover.
3. Consider an AI explanation layer after the checks are reliable. It can summarize verified findings and cite their evidence. Keep eligibility decisions reproducible from inventory and versioned rules.

## Engineering references

- [Broadcom pyVmomi](https://developer.broadcom.com/sdks/pyvmomi/latest/)
- [Red Hat MTV planning for VMware vSphere](https://docs.redhat.com/en/documentation/migration_toolkit_for_virtualization/2.12/html/planning_your_migration_to_red_hat_openshift_virtualization/assembly_planning-migration-vmware_mtv)
- [Codex repository review guidance](https://developers.openai.com/blog/custom-code-review-rules-for-codex/)
