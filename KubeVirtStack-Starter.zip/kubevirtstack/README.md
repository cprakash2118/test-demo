# KubeVirtStack

HawkStack's VMware-to-OpenShift Virtualization migration planning prototype. This starter contains the frontend from the private demo, a proposed API contract, and the development plan for the first connected pilot.

## Run the prototype

From the extracted kubevirtstack directory on Linux, macOS or WSL:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory frontend
```

On Windows with the Python launcher:

```powershell
py -3 -m http.server 8000 --bind 127.0.0.1 --directory frontend
```

Open http://localhost:8000 in a browser. Stop the server with Ctrl+C. No dependency installation or build is required. Python serves static files. The application runs in your browser.

## Try it

1. Select **Blocked**, then open **erp-app-01** to inspect its PCI device dependency.
2. Select **Create wave**, name it **Pilot wave**, and select **web-prod-01** and **api-gateway-01**.
3. Select **Save draft wave**, open the wave and verify 8 vCPU and 16 GiB. Refresh and reopen **Migration waves** to check local persistence.

The 18 sample VMs comprise 12 ready, four needing review and two blocked. Demo drafts belong to one browser and origin. The demo uses local fixtures. The API and lab integrations described in the plan are future work.

## Repository contents

| Path | Purpose |
|---|---|
| frontend/ | Runnable HTML, CSS and JavaScript exported from the published demo |
| backend/README.md | Backend implementation brief |
| contracts/openapi.json | Proposed first inventory read API |
| contracts/inventory.example.json | Contract fixture for parallel development |
| docs/BUILD_PLAN.md | Platform choices, milestones, estimates and Codex task briefs |
| AGENTS.md | Shared instructions for Codex contributors |

The three frontend files match published source commit `992bc9ea777fdaa0ec40a97c39f8fb8ea9c3009d`. This standalone export starts a new repository without the hosted demo's identity or Git metadata.

## Start a private Git repository

From the extracted kubevirtstack folder, run:

```sh
git init -b main
git add .
git diff --cached --stat
git commit -m "Add KubeVirtStack frontend prototype and pilot plan"
```

Create an empty private GitHub repository in your HawkStack organization. Use its clone URL in place of the placeholder:

```sh
git remote add origin <YOUR_REPOSITORY_CLONE_URL>
git push -u origin main
```

Create two working directories from that shared commit:

```sh
git worktree add ../kvs-frontend -b feat/inventory-ui main
git worktree add ../kvs-backend -b feat/inventory-api main
```

Open one Codex session in each worktree. Give each session its task from docs/BUILD_PLAN.md. Both can run on one laptop. Open a pull request for each branch and review the combined behavior before release.
