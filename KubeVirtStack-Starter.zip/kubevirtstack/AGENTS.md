# KubeVirtStack contributor instructions

Read README.md, docs/BUILD_PLAN.md, and contracts/openapi.json at the start of an inventory task.

- Frontend work belongs in frontend/. Keep the existing demo usable during the transition. Label sample data and handle empty, loading, failed and stale live reads explicitly.
- Backend work belongs in backend/. Use a provider-scoped identity for workloads. Keep vCenter access read-only during the pilot. Keep real endpoints, credentials and customer inventories out of fixtures, logs and Git.
- The maintainer owns contracts/. If either agent needs a schema change, describe the compatibility impact in a contract PR and update the example and both clients together.
- Each PR describes the user-visible outcome, how to reproduce it, checks run, and which parts were exercised against fixtures or an actual lab.
- Review wave eligibility, duplicate membership, missing evidence and retry behavior when those features change. Default unknown checks to unassessed.
