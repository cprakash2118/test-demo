# Backend implementation brief

Planned runtime: Python 3.12, FastAPI served by Uvicorn, PostgreSQL. Start with the two inventory read operations in ../contracts/openapi.json and the fixture beside it. Then add a separate server-side discovery adapter using pyVmomi. The backend developer’s first ticket and acceptance checks are in ../docs/BUILD_PLAN.md.

For the first connected pilot, run the collector inside the lab network with a dedicated read-only vCenter account and trusted CA. The web browser calls only KubeVirtStack. Persist the source/provider identity and managed object ID alongside each inventory record. Add an authorized refresh job in a later contract revision after the read API is integrated.

This directory contains the implementation brief. Start the existing frontend with the command in the root README.
